module com {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;

    opens com.application to javafx.fxml;

    exports com.application;

    opens com.application.controller to javafx.fxml;

    exports com.application.controller;
}
