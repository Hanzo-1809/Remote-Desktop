package com.application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class Start extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) {
        try {
            // Tải giao diện ban đầu
            scene = new Scene(loadFXML("mainstage"));
            // Thêm stylesheet
            addStylesheet("mainstage");
            stage.setScene(scene);
            stage.setTitle("Application Title"); // Đặt tiêu đề ứng dụng
            stage.initStyle(StageStyle.UNDECORATED);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Đổi giao diện chính của ứng dụng
     * 
     * @param fxml Tên file FXML (không có phần mở rộng)
     */
    public static void setRoot(String fxml) {
        try {
            scene.setRoot(loadFXML(fxml));
            addStylesheet(fxml);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Tải tệp FXML
     * 
     * @param fxml Tên file FXML (không có phần mở rộng)
     * @return Parent của giao diện
     * @throws IOException Nếu file không tìm thấy
     */
    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Start.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    /**
     * Thêm stylesheet vào scene
     * 
     * @param fxml Tên file FXML để xác định CSS
     */
    private static void addStylesheet(String fxml) {
        scene.getStylesheets().clear(); // Xóa stylesheet cũ
        String cssPath = "css/" + fxml + ".css";
        if (Start.class.getResource(cssPath) != null) {
            scene.getStylesheets().add(Start.class.getResource(cssPath).toExternalForm());
        } else {
            System.out.println("Warning: Stylesheet " + cssPath + " not found.");
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
