package com.application.controller.Client;
import java.io.*;
import java.net.Socket;

public class Client_ReceiveFile extends Thread {
    private static final int RECEIVE_PORT = 6788;
    private static final int SEND_PORT = 6789;
    private static final String SAVE_DIR = "D:\\FileTransfer\\"; // Đảm bảo thư mục này tồn tại

    private String ip;

    public Client_ReceiveFile(String ip) {
        this.ip = ip;
    }

    @Override
    public void run() {
        while (true) {
            receiveFile();
        }

    }

    private void receiveFile() {
        try (Socket socket = new Socket(ip, RECEIVE_PORT);
                DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            String fileName = dis.readUTF();
            long fileSize = dis.readLong();

            // Kiểm tra xem fileName và fileSize có hợp lệ không
            if (fileName == null || fileName.isEmpty()) {
                System.out.println("Loi: Ten file duoc nhan khong hop le.");
                return; // Nếu tên file không hợp lệ, dừng quá trình nhận file
            }

            File file = new File(SAVE_DIR + fileName);
            file.getParentFile().mkdirs(); // Tạo thư mục nếu không tồn tại

            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int read;
                long totalRead = 0;
                while ((read = dis.read(buffer, 0, buffer.length)) > 0) {
                    fos.write(buffer, 0, read);
                    totalRead += read;
                    if (totalRead >= fileSize)
                        break;
                }
                System.out.println("Da nhan file: " + fileName);
            } catch (IOException e) {
                System.out.println("Loi khi ghi file nhan duoc: " + e.getMessage());
            }
        } catch (IOException e) {
        }
    }

    public void sendFile(String filePath) {
        try (Socket socket = new Socket(ip, SEND_PORT);
                FileInputStream fis = new FileInputStream(filePath);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            File file = new File(filePath);
            dos.writeUTF(file.getName());
            dos.writeLong(file.length());

            byte[] buffer = new byte[4096];
            int read;
            while ((read = fis.read(buffer)) > 0) {
                dos.write(buffer, 0, read);
            }
            dos.flush();
            System.out.println("Da gui file: client" + file.getName());
        } catch (IOException e) {
            System.out.println("Loi khi gui file: client" + e.getMessage());
        }
    }

}
