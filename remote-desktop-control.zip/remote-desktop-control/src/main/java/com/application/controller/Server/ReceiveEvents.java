package com.application.controller.Server;

import java.awt.Robot;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

import com.application.model.SharedData;

import java.awt.event.InputEvent;

class ReceiveEvents extends Thread {
    Socket socket = null;
    Robot robot = null;
    boolean continueLoop = true;

    public ReceiveEvents(Socket socket, Robot robot) {
        this.socket = socket;
        this.robot = robot;
        start();
    }

    public void run() {

        try (Scanner scanner = new Scanner(socket.getInputStream())) {
            while (continueLoop) {
                if (SharedData.isServerStart()) {
                    socket.close();
                    return;
                }
                try {
                    int command = scanner.nextInt();
                    switch (command) {
                        case -1: // PRESS_MOUSE
                            robot.mousePress(scanner.nextInt());
                            break;
                        case -2: // RELEASE_MOUSE
                            robot.mouseRelease(scanner.nextInt());
                            break;
                        case -3: // PRESS_KEY
                            robot.keyPress(scanner.nextInt());
                            break;
                        case -4: // RELEASE_KEY
                            robot.keyRelease(scanner.nextInt());
                            break;
                        case -5: // MOVE_MOUSE
                            robot.mouseMove(scanner.nextInt(), scanner.nextInt());
                            break;
                        case -6: // DOUBLE_CLICK_MOUSE
                            int button = scanner.nextInt();
                            robot.mousePress(button);
                            robot.mouseRelease(button);
                            robot.mousePress(button);
                            robot.mouseRelease(button);
                            break;
                        case -7: // SCROLL_MOUSE
                            int wheelRotation = scanner.nextInt();
                            robot.mouseWheel(wheelRotation);
                            break;
                        case -8: // DRAG_MOUSE
                            int dragX = scanner.nextInt();
                            int dragY = scanner.nextInt();

                            robot.mouseMove(dragX, dragY);
                            break;

                        default:
                            System.out.println("Lệnh không hợp lệ: " + command);
                            break;
                    }
                } catch (Exception e) {

                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (socket != null && !socket.isClosed()) {
                    socket.close(); // Ensure socket is closed
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to stop the loop
    public void stopReceiving() {
        continueLoop = false;
    }
}