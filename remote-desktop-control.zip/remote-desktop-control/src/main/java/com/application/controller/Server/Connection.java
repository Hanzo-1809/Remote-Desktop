package com.application.controller.Server;

import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

import com.application.model.SharedData;

public class Connection {
    static Vector<ClientHandler> clientList = new Vector<>(); // Danh sách các client kết nối
    public ServerSocket serverSocket = null;
    public ServerSocket serverSocketFile = null;
    // public static void main(String[] args) throws Exception {
    // new Connection(8888, "password123");
    // }

    // Constructor
    public Connection(int port, int portfile, String value1) {
        try {
            // if (!SharedData.isServerStart()) {
            // stop();
            // System.out.println("Aloha.");
            // return;
            // }
            serverSocket = new ServerSocket(port);
            serverSocketFile = new ServerSocket(portfile);
            System.out.println("Awaiting Connection from Client");

            // Tạo thông số màn hình
            GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
            GraphicsDevice gDev = gEnv.getDefaultScreenDevice();
            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
            String width = "" + dim.getWidth();
            String height = "" + dim.getHeight();
            Rectangle rectangle = new Rectangle(dim);
            Robot robot = new Robot(gDev);

            drawGUI(); // Khởi tạo giao diện nếu cần

            // Lắng nghe các kết nối mới
            while (true) {
                if (SharedData.isServerStart()) {
                    stop();
                    return;
                }
                Socket socket = serverSocket.accept();
                Socket fileSocket = serverSocketFile.accept();

                System.out.println("New client connected!");

                // Tạo luồng mới để xử lý client này
                ClientHandler clientHandler = new ClientHandler(socket, fileSocket, value1, robot, rectangle, width,
                        height);
                clientList.add(clientHandler); // Thêm client vào danh sách
                clientHandler.start(); // Bắt đầu luồng
            }
        } catch (Exception ex) {
            // ex.printStackTrace();
            System.err.println("Connection reset by peer: " + ex.getMessage());
        }
    }

    public void stop() {
        try {
            // Dừng các client
            for (ClientHandler clientHandler : clientList) {
                clientHandler.stopClient();
            }

            // Đóng các ServerSocket
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
            if (serverSocketFile != null && !serverSocketFile.isClosed()) {
                serverSocketFile.close();
            }

            System.out.println("Server stopped successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void drawGUI() {
        // Khởi tạo giao diện nếu cần thiết (tạm thời để trống)
    }

    public void exit() {
        return;
    }

}

// Class xử lý mỗi kết nối client
class ClientHandler extends Thread {
    Socket socket;
    Socket fileSocket;
    DataInputStream password;
    DataOutputStream verify;
    String correctPassword;
    Robot robot;
    Rectangle screenRect;
    String width, height;

    public ClientHandler(Socket socket, Socket fileSocket, String correctPassword, Robot robot, Rectangle screenRect,
            String width,
            String height) {
        this.socket = socket;
        this.fileSocket = fileSocket;
        this.correctPassword = correctPassword;
        this.robot = robot;
        this.screenRect = screenRect;
        this.width = width;
        this.height = height;

        try {
            password = new DataInputStream(socket.getInputStream());
            verify = new DataOutputStream(socket.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            // Đọc mật khẩu từ client
            String clientPassword = password.readUTF();
            if (clientPassword.equals(correctPassword)) {
                // Xác thực thành công
                verify.writeUTF("valid");
                verify.writeUTF(width);
                verify.writeUTF(height);

                // Khởi chạy lớp SendScreen và ReceiveEvents để gửi màn hình và nhận sự kiện
                if (SharedData.isServerStart()) {
                    stopClient();
                    return;
                }
                SendScreen sendScreen = new SendScreen(socket, robot, screenRect);
                new ReceiveEvents(socket, robot);
                new FileReceive(fileSocket);
            } else {
                // Mật khẩu không đúng
                verify.writeUTF("Invalid");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void stopClient() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
            if (fileSocket != null && !fileSocket.isClosed()) {
                fileSocket.close();
            }
            System.out.println("Client connection stopped.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
