package com.application.controller.Server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server_SendFile extends Thread {
    private static final int RECEIVE_PORT = 6789;
    private static final int SEND_PORT = 6788;
    private static final String SAVE_DIR = "D:\\FileTransfer\\"; // Đảm bảo thư mục này tồn tại
    public static String path = "";

    @Override
    public void run() {
        new Thread(this::startReceiveFileServer).start();
        new Thread(this::startSendFileServer).start();
    }

    private void startReceiveFileServer() {
        try {
            ServerSocket serverSocketReceive = new ServerSocket(RECEIVE_PORT);
            System.out.println("Server nhan file tren port: " + RECEIVE_PORT);

            while (true) {
                try (Socket socket = serverSocketReceive.accept();
                        DataInputStream dis = new DataInputStream(socket.getInputStream())) {

                    String fileName = dis.readUTF();
                    long fileSize = dis.readLong();
                    File file = new File(SAVE_DIR + fileName);
                    file.getParentFile().mkdirs(); // Tạo thư mục nếu không tồn tại

                    try (FileOutputStream fos = new FileOutputStream(file)) {
                        byte[] buffer = new byte[4096];
                        int read;
                        long totalRead = 0;
                        while ((read = dis.read(buffer)) > 0) {
                            fos.write(buffer, 0, read);
                            totalRead += read;
                            if (totalRead >= fileSize)
                                break;
                        }
                        System.out.println("Receive file: " + fileName);
                    } catch (IOException e) {
                        System.out.println("Error file : " + e.getMessage());
                    }
                } catch (IOException e) {
                    System.out.println("Loi khi nhan file: server" + e.getMessage());
                }
            }
        } catch (IOException e) {
            // System.out.println("Loi khi khoi tao ServerSocket nhan file: " +
            // e.getMessage());
        }
    }

    public void startSendFileServer() {
        try {
            ServerSocket serverSocketSend = new ServerSocket(SEND_PORT);
            System.out.println("Server đang lang nghe đa gui file trên cong: " + SEND_PORT);

            while (true) {
                try (Socket socket = serverSocketSend.accept();
                        DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

                    if (path == null) {
                        continue;
                    }
                    File file = new File(path);

                    if (!file.exists()) {
                        // System.out.println("File không ton tai: " + path);
                        continue;
                    }
                    path = null; // Đặt path là null để tránh gửi lại file sau này

                    dos.writeUTF(file.getName()); // Gửi tên file
                    dos.writeLong(file.length()); // Gửi kích thước file

                    try (FileInputStream fis = new FileInputStream(file)) {
                        byte[] buffer = new byte[4096];
                        int read;
                        while ((read = fis.read(buffer)) > 0) {
                            dos.write(buffer, 0, read);
                        }
                        dos.flush();
                        System.out.println("Da gui file: server" + file.getName());
                    }
                } catch (IOException e) {
                    System.out.println("Loi khoi gui file: server" + e.getMessage());
                }
            }
        } catch (IOException e) {
            // System.out.println("Loi khi khoi tao ServerSocket gui file: " +
            // e.getMessage());
        }
    }

}
