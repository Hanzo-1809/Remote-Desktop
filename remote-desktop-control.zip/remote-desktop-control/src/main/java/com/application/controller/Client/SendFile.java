package com.application.controller.Client;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JPanel;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetListener;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.util.List;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.io.File;
import java.awt.datatransfer.DataFlavor;
import java.io.FileInputStream;
import java.io.DataOutputStream;


class SendFile implements DropTargetListener {
    static Socket fileSocket = null;
    private JPanel cPanel = null;
    private DataOutputStream dos;

    SendFile(Socket s, JPanel p) {
        fileSocket = s;
        cPanel = p;
        new DropTarget(cPanel, this);
        try {
            dos = new DataOutputStream(fileSocket.getOutputStream());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void drop(DropTargetDropEvent evt) {
        try {
            evt.acceptDrop(DnDConstants.ACTION_COPY);
            Transferable transferable = evt.getTransferable();
            List<File> droppedFiles = (List<File>) transferable.getTransferData(DataFlavor.javaFileListFlavor);

            int x = evt.getLocation().x;
            int y = evt.getLocation().y;

            for (File file : droppedFiles) {
                sendFileToServer(file, x, y);
            }
            System.out.println("File dropped at coordinates: " + x + ", " + y);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void sendFileToServer(File file, int x, int y) {
        try (FileInputStream fis = new FileInputStream(file)) {
            dos.writeUTF(file.getName());
            dos.writeInt(x);
            dos.writeInt(y);
            dos.flush();

            long length = file.length();
            dos.writeLong(length);
            dos.flush();

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
            dos.flush();
            System.out.println("File sent: " + file.getName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Implementations of other DropTargetListener methods
    @Override
    public void dragEnter(DropTargetDragEvent dtde) {
    }

    @Override
    public void dragOver(DropTargetDragEvent dtde) {
    }

    @Override
    public void dropActionChanged(DropTargetDragEvent dtde) {
    }

    @Override
    public void dragExit(DropTargetEvent dte) {
    }

    // Close resources when SendFile is no longer needed
    public void close() {
        try {
            if (dos != null)
                dos.close();
            if (fileSocket != null && !fileSocket.isClosed())
                fileSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}