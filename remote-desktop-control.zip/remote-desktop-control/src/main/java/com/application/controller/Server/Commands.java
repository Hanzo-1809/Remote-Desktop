package com.application.controller.Server;

public enum Commands {
	PRESS_MOUSE(-1), // Nhấn chuột
	RELEASE_MOUSE(-2), // Nhả chuột
	PRESS_KEY(-3), // Nhấn phím
	RELEASE_KEY(-4), // Nhả phím
	MOVE_MOUSE(-5), // Di chuyển chuột
	DOUBLE_CLICK_MOUSE(-6), // Nhấp đúp chuột
	SCROLL_MOUSE(-7), // Cuộn chuột
	DRAG_MOUSE(-8);

	private int abbrev;

	Commands(int abbrev) {
		this.abbrev = abbrev;
	}

	public int getAbbrev() {
		return abbrev;
	}
}
