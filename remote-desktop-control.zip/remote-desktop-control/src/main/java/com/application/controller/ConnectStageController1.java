package com.application.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.application.Start;
import com.application.model.SharedData;
import com.application.controller.Client.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ConnectStageController1 implements Initializable {

    public Socket cSocket = null;
    public Socket fileSocket = null;
    DataOutputStream psswrchk = null;
    DataInputStream verification = null;
    String verify = "";
    String width = "", height = "";

    @FXML
    private Button connectBtn1;

    @FXML
    private Button cancelBtn;

    @FXML
    private TextField clientPasswordTextField;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        connectBtn1.setOnAction(event -> {
            SharedData.setPassRemote(clientPasswordTextField.getText());
            try {
                cSocket = new Socket(SharedData.getIpRemote(), Integer.parseInt(SharedData.getPortConnect()));
                fileSocket = new Socket(SharedData.getIpRemote(), Integer.parseInt(SharedData.getPortFile()));
                SharedData.setFileClient(true);
                SharedData.setClient_receiveFile(new Client_ReceiveFile(SharedData.getIpRemote()));
                try {
                    System.out.println("Connect button clicked");
                    psswrchk = new DataOutputStream(cSocket.getOutputStream());
                    verification = new DataInputStream(cSocket.getInputStream());
                    psswrchk.writeUTF(clientPasswordTextField.getText());
                    verify = verification.readUTF();

                } catch (IOException e) {
                    e.printStackTrace();
                    closeSockets(); // Đóng socket nếu xảy ra lỗi.
                    return;
                }
                if (verify.equals("valid")) {
                    try {
                        width = verification.readUTF();
                        height = verification.readUTF();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Thread frameThread = new Thread(() -> {
                        try {
                            Frame abc = new Frame(cSocket, fileSocket, width, height);
                            abc.start();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                    frameThread.start();
                    SharedData.setFileClient(false);
                } else {
                    System.out.println("enter the valid password");
                    JOptionPane.showMessageDialog(null, "Incorrect password", "Error",
                            JOptionPane.ERROR_MESSAGE);

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
            currentStage.close();
        });
        cancelBtn.setOnAction(event -> {
            Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
            currentStage.close();
        });
    }

    private void closeSockets() {
        try {
            if (cSocket != null && !cSocket.isClosed())
                cSocket.close();
            if (fileSocket != null && !fileSocket.isClosed())
                fileSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
