package com.application.controller.Client;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

class ReceiveScreen extends Thread {
    private DatagramSocket socket;
    private JPanel cPanel;
    private boolean continueLoop = true;
    private Socket soc;
    private BlockingQueue<BufferedImage> imageQueue = new ArrayBlockingQueue<>(20);
    private static final int PACKET_SIZE = 60000;
    private static final int TIMEOUT_MS = 1000;
    private static final int MAX_RETRIES = 5;

    public ReceiveScreen(Socket socket, JPanel p) {
        try {
            this.soc = socket;
            this.socket = new DatagramSocket();
            this.cPanel = p;
            this.start();
            new ImageProcessor(imageQueue, cPanel).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            InetAddress serverAddress = InetAddress.getByName(soc.getInetAddress().getHostAddress());
            int retryCount = 0;

            while (continueLoop) {
                try {
                    DatagramPacket req = new DatagramPacket(new byte[100], 100, serverAddress, 7777);
                    socket.send(req);

                    DatagramPacket res = new DatagramPacket(new byte[100], 100);
                    socket.setSoTimeout(TIMEOUT_MS);
                    socket.receive(res);

                    String str = new String(res.getData(), 0, res.getLength()).trim();

                    if (str.isEmpty() || !str.contains(",")) {
                        System.out.println("Invalid response format: " + str);
                        continue;
                    }

                    String[] strsplit = str.split(",");
                    if (strsplit.length != 2) {
                        System.out.println("Unexpected response format: " + str);
                        continue;
                    }

                    int imageLength = Integer.parseInt(strsplit[0].trim());
                    int packetSize = Integer.parseInt(strsplit[1].trim());
                    int numPackets = (int) Math.ceil((double) imageLength / packetSize);

                    Map<Integer, byte[]> packetMap = new HashMap<>();
                    int receivedBytes = 0;
                    retryCount = 0;

                    while (receivedBytes < imageLength && retryCount < MAX_RETRIES) {
                        DatagramPacket dataPacket = new DatagramPacket(new byte[packetSize + 1], packetSize + 1);
                        try {
                            socket.receive(dataPacket);
                            byte[] dataBuffer = dataPacket.getData();
                            int sequenceNumber = dataBuffer[0] & 0xFF;

                            if (!packetMap.containsKey(sequenceNumber)) {
                                byte[] packetData = new byte[dataPacket.getLength() - 1];
                                System.arraycopy(dataBuffer, 1, packetData, 0, packetData.length);
                                packetMap.put(sequenceNumber, packetData);
                                receivedBytes += packetData.length;

                                socket.send(new DatagramPacket(new byte[] { (byte) sequenceNumber }, 1, serverAddress,
                                        7777));
                            }
                        } catch (IOException e) {
                            retryCount++;
                            System.out.println(
                                    "Timeout waiting for packet #" + (receivedBytes / packetSize) + ", retrying...");
                            continue;
                        }
                    }

                    if (receivedBytes >= imageLength) {
                        byte[] completeImage = new byte[imageLength];
                        int offset = 0;
                        for (int i = 0; i < numPackets; i++) {
                            byte[] packetData = packetMap.get(i);
                            if (packetData != null) {
                                System.arraycopy(packetData, 0, completeImage, offset, packetData.length);
                                offset += packetData.length;
                            } else {
                                System.out.println("Missing packet #" + i);
                                break;
                            }
                        }

                        ByteArrayInputStream imageStream = new ByteArrayInputStream(completeImage);
                        BufferedImage img = ImageIO.read(imageStream);
                        if (img != null) {
                            if (!imageQueue.offer(img)) {
                                System.out.println("Image queue full, discarding image");
                            }
                        }
                    } else {
                        System.out.println("Failed to receive complete image, retrying...");
                    }

                    packetMap.clear();
                } catch (IOException ex) {
                    retryCount++;
                    System.out.println("Timeout waiting for response from server, retrying...");
                    if (retryCount >= MAX_RETRIES) {
                        System.out.println("Max retries reached. Stopping...");
                        break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ImageProcessor extends Thread {
    private BlockingQueue<BufferedImage> imageQueue;
    private JPanel cPanel;

    public ImageProcessor(BlockingQueue<BufferedImage> imageQueue, JPanel cPanel) {
        this.imageQueue = imageQueue;
        this.cPanel = cPanel;
    }

    @Override
    public void run() {
        while (true) {
            try {
                BufferedImage img = imageQueue.take();
                drawImage(img);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void drawImage(BufferedImage img) {
        if (img != null && cPanel.getWidth() > 0 && cPanel.getHeight() > 0) {
            BufferedImage bufferedImage = new BufferedImage(cPanel.getWidth(), cPanel.getHeight(),
                    BufferedImage.TYPE_INT_RGB);
            Graphics bufferedGraphics = bufferedImage.getGraphics();
            Image scaledImage = img.getScaledInstance(cPanel.getWidth(), cPanel.getHeight(), Image.SCALE_SMOOTH);
            bufferedGraphics.drawImage(scaledImage, 0, 0, cPanel);
            bufferedGraphics.dispose();

            Graphics graphics = cPanel.getGraphics();
            graphics.drawImage(bufferedImage, 0, 0, cPanel);
            graphics.dispose();
        } else {
            System.out.println(
                    "Invalid JPanel dimensions: Width = " + cPanel.getWidth() + ", Height = " + cPanel.getHeight());
        }
    }
}
