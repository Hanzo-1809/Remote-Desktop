package com.application.controller;

import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import com.application.Start;
import com.application.model.SharedData;
import com.application.controller.Client.Authenticate;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ConnectStageController implements Initializable {

    @FXML
    private Button connectBtn;

    @FXML
    private Button cancelBtn;

    @FXML
    private TextField clientAddressTextField;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        connectBtn.setOnAction(event -> {
            try {

                SharedData.setIpRemote(clientAddressTextField.getText());
                FXMLLoader loader = new
                FXMLLoader(Start.class.getResource("connectStage1.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);

                Stage currentStage = (Stage) connectBtn.getScene().getWindow();
                currentStage.setScene(scene);

            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        cancelBtn.setOnAction(event -> {
            Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
            currentStage.close();
        });
    }
}
