package com.application.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ResourceBundle;
import java.awt.Desktop;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class TagBarController implements Initializable {

    @FXML
    private Button closeBtn;

    @FXML
    private Button helpBtn;

    @FXML
    private Button cancelBtn;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        closeBtn.setOnAction(event -> {
            System.exit(0);
        });
        helpBtn.setOnAction(event -> {
            try {
                Desktop.getDesktop().browse(new URI("https://github.com/Minhduc252"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (URISyntaxException e) {
                throw new RuntimeException(e);
            }
        });
        cancelBtn.setOnAction(e -> {
            ((Stage) cancelBtn.getScene().getWindow()).setIconified(true);
        });
    }
}
