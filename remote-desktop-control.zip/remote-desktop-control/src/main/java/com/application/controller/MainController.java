package com.application.controller;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import com.application.Start;
import com.application.model.SharedData;
import com.application.controller.Server.Connection;
import com.application.controller.Server.Server_SendFile;

public class MainController implements Initializable {

    @FXML
    private Label timeLabel;

    @FXML
    private Label connectLabel;

    @FXML
    private Label dateLabel;

    @FXML
    private Button configBtn;

    @FXML
    private Button fileTransferBtn;

    @FXML
    private Button connectBtn;

    @FXML
    private Button remoteBtn;

    private boolean isServerStart;

    private String password;

    private Connection serverConnection;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private volatile boolean isConnectionThreadRunning = false; // Biến kiểm tra trạng thái của luồng
    private Thread connectionThread = null; // Tham chiếu đến thread

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        isServerStart = false;

        // Khởi tạo đồng hồ hiển thị thời gian và ngày tháng
        initializeDateTimeUpdater();

        // Cài đặt hành động cho nút "Connect"
        connectBtn.setOnAction(event -> toggleServerConnection());

        // Cài đặt hành động cho nút "Config"
        configBtn.setOnAction(event -> {
            try {
                Start.setRoot("serverConfiguration");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Cài đặt nút hành động cho nút "File Transfer"
        fileTransferBtn.setOnAction(event -> {
            if (!SharedData.isFileServer() && !SharedData.isFileClient()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Error connecting to the remote device.");
                alert.setContentText("Cannot send files without a connection between the two devices.");

                alert.getDialogPane().getStylesheets()
                        .add(getClass().getResource("/com/application/styles/alert-style.css").toExternalForm());
                alert.showAndWait();

            } else {
                try {
                    Start.setRoot("fileTransfer");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // cài đặt hành động cho nút "Remote "
        remoteBtn.setOnAction(event -> {
            if (SharedData.isFileServer()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Error");
                alert.setHeaderText("You are already connected to a remote device");
                alert.showAndWait();

            } else {
                openConnectStage();
            }
        });
    }

    /**
     * Khởi tạo cập nhật thời gian và ngày tháng
     */
    private void initializeDateTimeUpdater() {
        timeLabel.setText(LocalTime.now().format(TIME_FORMATTER));
        dateLabel.setText(LocalDate.now().format(DATE_FORMATTER));
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> updateDateTime()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    /**
     * Cập nhật thời gian và ngày tháng
     */
    private void updateDateTime() {
        timeLabel.setText(LocalTime.now().format(TIME_FORMATTER));
        dateLabel.setText(LocalDate.now().format(DATE_FORMATTER));
    }

    /**
     * Xử lý chuyển đổi trạng thái server và thay đổi giao diện nút Connect
     */

    private void toggleServerConnection() {
        if (!isServerStart) {
            // Bật server
            isServerStart = true;
            SharedData.setServer(false);
            SharedData.setFileServer(true);
            SharedData.setServer_sendFile(new Server_SendFile());
            connectBtn.getStyleClass().add("connected");
            connectLabel.setText("Disconnect");
            password = SharedData.getPassword();
            System.out.println("Password shared: " + password);
            if (!SharedData.isServerStart()) {
                Runnable connectionTask = new Runnable() {
                    @Override
                    public void run() {
                        try {
                            // Thực hiện một số thao tác trước khi kết nối (ví dụ: sleep)
                            Thread.sleep(10); // Delay để giả lập khởi tạo

                            // Tạo đối tượng Connection và bắt đầu lắng nghe kết nối client
                            serverConnection = new Connection(
                                    Integer.parseInt(SharedData.getPortConnect()),
                                    Integer.parseInt(SharedData.getPortFile()),
                                    password);
                        } catch (InterruptedException e) {
                            System.out.println("Connection thread was interrupted.");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };

                // Tạo và bắt đầu luồng cho server
                connectionThread = new Thread(connectionTask);
                connectionThread.start();
            }
            // Tạo và bắt đầu luồng connection

        } else {
            // Tắt server
            isServerStart = false;
            SharedData.setFileServer(false);
            connectBtn.getStyleClass().remove("connected");
            connectLabel.setText("Connect");
            SharedData.setServer(true);
            if (serverConnection != null) {
                serverConnection.stop();
                serverConnection = null;
                System.out.println("Server stopped");
            }
            // Reload toàn bộ ứng dụng
            // reloadApplication();
        }
    }

    /**
     * Mở cửa sổ Connect Stage
     */

    private void openConnectStage() {
        try {
            System.out.println(getClass().getResource("/com/application/connectStage.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/application/connectStage.fxml"));
            Parent root = loader.load();

            // Tạo một Scene mới và đặt root là giao diện đã tải
            Scene scene = new Scene(root);

            // Tạo một Stage mới (cửa sổ mới)
            Stage newStage = new Stage();
            newStage.setTitle("Connect Stage");
            newStage.setScene(scene);
            newStage.initStyle(StageStyle.UNDECORATED);

            // Hiển thị cửa sổ mới
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
