package com.application.controller;

import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import com.application.Start;
import com.application.controller.Client.Client_ReceiveFile;
import com.application.controller.Server.Server_SendFile;
import com.application.model.SharedData;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.stage.FileChooser;

public class FileTransferController implements Initializable {
    @FXML
    private Button fileChooseBtn;

    @FXML
    private TextField filePathTextField;

    @FXML
    private TextField clientAddress;

    @FXML
    private Button backBtn;

    @FXML
    private Button sendBtn;

    // private Client_ReceiveFile client_receiveFile;
    // private Server_SendFile server_sendFile;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        fileChooseBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(null);
            filePathTextField.setText(file.getAbsolutePath());
        });
        fileChooseBtn.setOnDragOver(event -> {
            if (event.getGestureSource() != fileChooseBtn
                    && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });
        fileChooseBtn.setOnDragDropped(e -> {
            Dragboard db = e.getDragboard();
            if (db.hasFiles()) {
                List<File> files = db.getFiles();
                String path = "";
                for (File file : files) {
                    path += file.getAbsolutePath() + "\n";
                }
                filePathTextField.setText(path);
            }
            e.setDropCompleted(true);
            e.consume();
        });
        sendBtn.setOnAction(event -> {
            String filePath = filePathTextField.getText();
            if (filePath != null && !filePath.isEmpty()) {
                filePath = filePath.replace("\\", "\\\\");
                if (SharedData.isFileServer() == true) {
                    SharedData.getServer_sendFile().path = filePath;
                    SharedData.getServer_sendFile().startSendFileServer();
                } else {
                    if (SharedData.isFileClient() == true) {
                        SharedData.getClient_receiveFile().sendFile(filePath);
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Please connect to a partner first",
                                "Error",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }

            } else {
                filePathTextField.setText("No file selected to send.");
            }
        });
        backBtn.setOnAction(event -> {
            Start.setRoot("mainstage");
        });
    }
}
