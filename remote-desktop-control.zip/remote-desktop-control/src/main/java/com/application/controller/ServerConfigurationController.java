package com.application.controller;

import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import com.application.Start;
import com.application.model.SharedData;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.DirectoryChooser;

public class ServerConfigurationController implements Initializable {
    @FXML
    private Button backBtn;

    @FXML
    private Button editBtn;

    @FXML
    private TextField ipTextField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private TextField dirTextField;

    @FXML
    private ImageView editBtnImage;

    @FXML
    private Button fileChooseBtn;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        passwordTextField.setText(SharedData.getPassword());
        backBtn.setOnAction(event -> {
            Start.setRoot("mainstage");
        });
        try {
            ipTextField.setText(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            e.printStackTrace();
            ipTextField.setText("Unknown Host");
        }
        editBtn.setOnAction(event -> {
            if (editBtnImage.getImage().getUrl().contains("image/pen.png")) {
                // ipTextField.setDisable(false);
                passwordTextField.setDisable(false);
                dirTextField.setDisable(false);
                String path = editBtnImage.getImage().getUrl();
                fileChooseBtn.setVisible(true);
                editBtnImage.setImage(new Image(path.replace("image/pen.png", "image/check.png")));
            } else {
                ipTextField.setDisable(true);
                passwordTextField.setDisable(true);
                dirTextField.setDisable(true);
                String path = editBtnImage.getImage().getUrl();
                fileChooseBtn.setVisible(false);
                editBtnImage.setImage(new Image(path.replace("image/check.png", "image/pen.png")));
                SharedData.setPassword(passwordTextField.getText());
            }
        });
        fileChooseBtn.setOnAction(e -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            File selectedDirectory = directoryChooser.showDialog(null);
            if (selectedDirectory != null) {
                dirTextField.setText(selectedDirectory.getAbsolutePath());
            }
        });
    }

}
