package com.application.controller.Server;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;

import com.application.model.SharedData;

import java.net.Socket;

class SendScreen extends Thread {
    private Robot robot;
    private Rectangle rectangle;
    private static final int PORT = 7777;
    private static final int PACKET_SIZE = 60000; // Kích thước gói
    private static final int TIMEOUT_MS = 1000;
    private static final int MAX_ATTEMPTS = 5;
    static byte[] tmp;

    public SendScreen(Socket socket, Robot robot, Rectangle rect) {
        this.robot = robot;
        this.rectangle = rect;
        this.start();
    }

    @Override
    public void run() {
        try {
            DatagramSocket socket = new DatagramSocket(PORT);
            Robot r = new Robot();
            while (true) {
                if (SharedData.isServerStart()) {
                    socket.close();
                    return;
                }
                try {
                    DatagramPacket req = new DatagramPacket(new byte[100], 100);
                    socket.receive(req);

                    Rectangle capture = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                    BufferedImage img = r.createScreenCapture(capture);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(img, "jpeg", baos);
                    tmp = baos.toByteArray();

                    String str = tmp.length + "," + PACKET_SIZE;
                    DatagramPacket res = new DatagramPacket(str.getBytes(), str.length(), req.getAddress(),
                            req.getPort());
                    socket.send(res);

                    int offset = 0;
                    byte sequenceNumber = 0;
                    Set<Integer> confirmedPackets = new HashSet<>();

                    while (offset < tmp.length) {
                        int length = Math.min(PACKET_SIZE, tmp.length - offset);
                        byte[] sendBuffer = new byte[length + 1];
                        sendBuffer[0] = sequenceNumber;
                        System.arraycopy(tmp, offset, sendBuffer, 1, length);

                        DatagramPacket dataPacket = new DatagramPacket(sendBuffer, sendBuffer.length, req.getAddress(),
                                req.getPort());
                        socket.send(dataPacket);
                        System.out.println("Send: " + sequenceNumber);

                        int attempts = 0;
                        boolean ackReceived = false;

                        // Đợi xác nhận từ Client cho gói tin đã gửi
                        while (attempts < MAX_ATTEMPTS && !ackReceived) {
                            try {
                                byte[] ackBuffer = new byte[1];
                                DatagramPacket ackPacket = new DatagramPacket(ackBuffer, ackBuffer.length);
                                socket.setSoTimeout(TIMEOUT_MS); // Đặt thời gian chờ cho gói ACK
                                socket.receive(ackPacket);

                                if (ackBuffer[0] == sequenceNumber) {
                                    ackReceived = true;
                                    confirmedPackets.add((int) sequenceNumber);
                                    System.out.println("Received ACK for packet: " + sequenceNumber);
                                }
                            } catch (IOException e) {
                                attempts++;
                                System.out.println(
                                        "No ACK received for packet: " + sequenceNumber + ", retrying... " + attempts);
                                socket.send(dataPacket); // Gửi lại gói tin nếu không nhận được ACK
                            }
                        }

                        // Nếu sau tối đa lần thử mà không nhận được ACK, báo lỗi và bỏ qua gói tin này
                        if (!ackReceived) {
                            System.out.println("Failed to receive ACK for packet " + sequenceNumber + " after "
                                    + MAX_ATTEMPTS + " attempts.");
                            break;
                        }

                        offset += length;
                        sequenceNumber++;
                    }

                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }
}
