package com.application.controller.Server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.application.model.SharedData;

public class FileReceive extends Thread {
    private Socket socket;

    public FileReceive(Socket socket) {
        this.socket = socket;
        start(); // Bắt đầu thread khi khởi tạo
    }

    @Override
    public void run() {
        while (true) { // Vòng lặp chờ nhận file
            if (SharedData.isServerStart()) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return;
                }
            try {
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                // Nhận tên file
                String fileName = dis.readUTF();
                System.out.println("File name received: " + fileName);

                // Nhận tọa độ (nếu cần)
                int x = dis.readInt();
                int y = dis.readInt();
                System.out.println("Coordinates received: (" + x + ", " + y + ")");

                // Nhận kích thước file
                long length = dis.readLong();
                System.out.println("Receiving file: " + fileName + " Size: " + length);

                // Đường dẫn lưu file
                String currentDirectory = "D:\\FileTransfer"; // Đường dẫn để lưu file
                File directory = new File(currentDirectory);

                // Kiểm tra và tạo thư mục nếu chưa tồn tại
                if (!directory.exists()) {
                    directory.mkdirs();
                    System.out.println("Directory created at: " + directory.getAbsolutePath());
                }

                File outputFile = new File(directory, fileName);

                try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    long totalBytesRead = 0;

                    // Đọc và ghi nội dung file
                    while (totalBytesRead < length && (bytesRead = dis.read(buffer, 0,
                            (int) Math.min(buffer.length, length - totalBytesRead))) != -1) {
                        fos.write(buffer, 0, bytesRead);
                        totalBytesRead += bytesRead;
                    }
                    fos.flush();
                    System.out.println("File received and saved to: " + outputFile.getAbsolutePath());
                }

            } catch (IOException e) {
                // e.printStackTrace();
            }
        }
    }
}
