package com.application.model;

import com.application.controller.Client.Client_ReceiveFile;
import com.application.controller.Server.Server_SendFile;

public class SharedData {
    private static String password = "123";;
    private static String portconnect = "4907";
    private static String portFile = "6666";
    private static boolean isServerStart = false;
    private static boolean isFileTransfer = false;
    private static String ipRemote = "";
    private static String passRemote = "";
    private static boolean fileServer = false;
    private static boolean fileClient = false;

    private static Client_ReceiveFile client_receiveFile;
    private static Server_SendFile server_sendFile;

    public static Client_ReceiveFile getClient_receiveFile() {
        return client_receiveFile;
    }

    public static void setClient_receiveFile(Client_ReceiveFile client_receiveFile) {
        SharedData.client_receiveFile = client_receiveFile;
        SharedData.client_receiveFile.start();
    }

    public static Server_SendFile getServer_sendFile() {
        return server_sendFile;
    }

    public static void setServer_sendFile(Server_SendFile server_sendFile) {
        SharedData.server_sendFile = server_sendFile;
        SharedData.server_sendFile.start();
    }

    public static boolean isFileClient() {
        return fileClient;
    }

    public static void setFileClient(boolean fileClient) {
        SharedData.fileClient = fileClient;
    }

    public static boolean isFileServer() {
        return fileServer;
    }

    public static void setFileServer(boolean fileServer) {
        SharedData.fileServer = fileServer;
    }

    public static String getIpRemote() {
        return ipRemote;
    }

    public static void setIpRemote(String ipRemote) {
        SharedData.ipRemote = ipRemote;
    }

    public static String getPassRemote() {
        return passRemote;
    }

    public static void setPassRemote(String passRemote) {
        SharedData.passRemote = passRemote;
    }

    public static String getPortFile() {
        return portFile;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String newPassword) {
        password = newPassword;
    }

    public static String getPortConnect() {
        return portconnect;
    }

    public static boolean isServerStart() {
        return isServerStart;
    }

    public static void setServer(boolean isStart) {
        isServerStart = isStart;
    }

}